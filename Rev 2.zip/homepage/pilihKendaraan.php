<?php require 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="asset/css/style.css">
    <link rel="stylesheet" type="text/css" href="asset/css/bootstrap.css">
    <link rel="stylesheet" href="asset/fontawesome-free-5.15.3-web/css/all.css">
    <script src="assets/js/main.js"></script>
    <script src="asset/js/bootstrap.js"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style media="screen">
      *{
        font-family: oswald;
      }
      .jumbotron{
        background-image: url(asset/image/background.jpeg);
        background-size: cover;
        height: 640px;
      }
      .size{
        height: 270px;
        width: 270px;
        padding: 20px;
        border-radius: 60px;
      }
      .form-select{
        margin: 0 auto;
        display: block;
      }
      @media (min-width: 992px){
        .jumbotron{
          height: 625px;
        }
      }
    </style>
    <title>Document</title>
</head>
<body>
    <nav class="navbar navbar-light">
        <div class="container-fluid">
          <span class="navbar-brand mb-0 h1" style="color: white;"><a href="index.php"><i class="fas fa-arrow-left"></i></a> &ensp;</i> Pilih Kendaraan</span>
        </div>
    </nav>

    <div class="bg-img">
    <div class="jumbotron jumbotron-fluid">
      <div class="container text-center pt-4">
        <form action="hasil.php" method="get">
            <h3 class="text-center mb-4">Verifikasi Lagi Jurusan Anda </h3>
          <select  class="form-select form-select-md" name="loktujuan" style="width:60%;" required>
            <option value="">Pilih Jurusan </option>
            <?php while ($value = mysqli_fetch_assoc($hasil)):?>
            <option value="<?php echo $value['id_angkot'] ?>"><?php echo $value["jurusan"];?></option>
            <?php endwhile; ?>
          </select>

          <div class="angkot">
               <button type="submit" class="myButton">Angkot</button>
          </div>
          <div class="space">
              
          </div>
          <div class="online">
               <a href="#" class="myButton">Online</a>
          </div>
        </form>
      </div>
    </div> 
    </div>
    

</body>
</html>